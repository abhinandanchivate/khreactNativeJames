import axios from "axios";

export default axios.create({
  baseURL: "https://6b98-24-12-149-49.ngrok.io",
});
